package weekEleven.activity23;

import static org.junit.jupiter.api.Assertions.*;
import static weekEleven.activity23.Recursion.alphaBackwards;
import static weekEleven.activity23.Recursion.countdown;

class RecursionTest {
    public static void main(String[] args) {
            int num =3;
            char letter = 'z';
            countdown(num);
            alphaBackwards(letter);

        }

    }
