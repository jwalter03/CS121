package weekEleven.activity24;

import static org.junit.jupiter.api.Assertions.*;
import static weekEleven.activity24.BigO.*;

class BigOTest {
    public static void main(String[] args) {
        int n = 5;
        printOnce(n);
        printNTimes(n);
        printNSquaredTimes(n);
    }

}