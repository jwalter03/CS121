package weekSix.classActivity;

public class testClass {
    public static void main(String[] args) {
        SandwichClass Sandwich = new SandwichClass("White","colby jack","mayo");
        Sandwich.setSandwiches(2);
        Sandwich.setMeat("ham");
        Sandwich.displayInfo();
    }

}
