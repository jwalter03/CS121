package weekSix;

public class sandwichClass {
    int Sandwiches;
    String Bread, Meat, Cheese, Toppings;

    sandwichClass(String bread, String meat, String cheese, String toppings, int sandwiches) {
        this.Bread = bread;
        this.Meat = meat;
        this.Cheese = cheese;
        this.Toppings = toppings;
        this.Sandwiches = sandwiches;
    }
    public void displayInfo(){
        System.out.printf("Your sandwich has %s bread, %s , %s cheese and %s . You only made %d sandwiches.",Bread, Meat, Cheese, Toppings, Sandwiches);
    }
}