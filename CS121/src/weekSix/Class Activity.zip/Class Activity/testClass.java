package weekSix;

public class testClass {
    public static void main(String[] args) {
        sandwichClass Sandwich = new sandwichClass("White", "ham", "colby jack", "mayo", 1);
        Sandwich.displayInfo();
    }

}
